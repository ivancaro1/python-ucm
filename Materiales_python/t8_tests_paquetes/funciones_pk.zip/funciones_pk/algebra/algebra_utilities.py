def gcd(a: int, b: int) -> int:
    '''
    Returns the Greatest common divisor (gcd) of a and b.

    :param a: non negative integer
    :param b: positve integer
    :returns: the gcd of a and b
    :raises ValueError: if
      - a is negatve
      - b is non positive

    Examples
    --------
    >>> gcd(24, 16)
    8

    >>> gcd(30, 35)
    5

    >>> gcd(-3, 4)
    Traceback (most recent call last):
        ...
    ValueError: a = -3 must be non negative

    >>> gcd(3, 0)
    Traceback (most recent call last):
        ...
    ValueError: b = 0 must be a positive integer
    '''

    if a<0:
        raise ValueError(f'a = {a} must be non negative')
    if b<=0:
        raise ValueError(f'b = {b} must be a positive integer')

    while b!=0:
        r = a%b
        a = b
        b = r
    return a


"""if __name__ == "__main__":
    import doctest
    doctest.testmod()"""
