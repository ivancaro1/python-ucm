# tomorrow.py
from datetime import date, timedelta

def calcular_tomorrow() -> date:
    """Devuelve la fecha correspondiente al día de mañana."""
    return date.today() + timedelta(days=1)