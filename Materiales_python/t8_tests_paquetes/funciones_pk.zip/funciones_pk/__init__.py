from .algebra import gcd
from .ingesta_datos_api import read_data, mayor
from .funciones import factorial
from .tomorrow import calcular_tomorrow

__all__ = [ 'funciones', 'algebra', 'factorial', 'gcd' , 'calcular_tomorrow']
#__all__ = ['algebra', 'tomorrow']