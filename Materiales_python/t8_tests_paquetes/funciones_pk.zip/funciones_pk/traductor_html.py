
import requests
import bs4

def traduce_wikipedia(palabra: str, codigo_idioma: str) -> str | None:
    link = f"https://es.wikipedia.org/wiki/{palabra}"

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                      "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"
    }

    try:
        resp = requests.get(link, headers=headers, timeout=15)
        #print("status:", resp.status_code, "url:", resp.url)
        if resp.status_code != 200:
            return None
    except requests.RequestException as e:
        print("Error de conexión:", e)
        return None

    page = bs4.BeautifulSoup(resp.text, features="html.parser")
    trad = page.find_all(
        "a",
        attrs={"class": "interlanguage-link-target", "hreflang": codigo_idioma},
        limit=1
    )
    #print(trad)
    if len(trad) > 0:
        resp_text = trad[0].attrs["data-title"]
        return resp_text.strip()

    return None


if __name__ == "__main__":
    print(traduce_wikipedia("Casa", "en"))
