

def factorial_iterativo(n:int)->int:
    """
    Calcula el factorial de un número entero no negativo de forma iterativa.

    El factorial de un número ``n`` se define como el producto de todos los
    enteros positivos desde 1 hasta ``n``. Por convención, el factorial de 0 es 1.

    :param n: Un número entero no negativo.
    :type n: int
    :return: El factorial del número dado.
    :rtype: int
    :raises ValueError: Si el número proporcionado es negativo.

    Examples
    --------
    >>> factorial_iterativo(4)
    24
    >>> factorial_iterativo(0)
    1
    >>> factorial_iterativo(1)
    1
    >>> factorial_rec(-3)
    Traceback (most recent call last):
      ...
    ValueError: El número debe ser un entero no negativo.
    """
    if n < 0:
        raise ValueError("El número debe ser un entero no negativo.")
    resultado = 1
    for i in range(2, n + 1):
        resultado *= i
    return resultado


def factorial_rec(n:int)-> int:
    """
    Calcula el factorial de un número entero no negativo de forma recursiva.

    El factorial de un número ``n`` se define como el producto de todos los
    enteros positivos desde 1 hasta ``n``. Por convención, el factorial de 0 es 1.

    :param n: Un número entero no negativo.
    :type n: int
    :return: El factorial del número dado.
    :rtype: int
    :raises ValueError: Si el número proporcionado es negativo.

    Examples
    --------
    >>> factorial_rec(6)
    720
    >>> factorial_rec(0)
    1
    >>> factorial_rec(1)
    1
    >>> factorial_rec(-4)
    Traceback (most recent call last):
      ...
    ValueError: El número debe ser un entero no negativo.
    """
    if n < 0:
        raise ValueError("El número debe ser un entero no negativo.")
    if n == 0 or n == 1:
        return 1
    return n * factorial_rec(n - 1)

def factorial(lista:list[int])-> list[int]:
    """
    Calcula el factorial de una lista de números entero no negativo. El cálculo se hará
    de forma iterativa o recursiva dependiendo del valor del número.

    El factorial de un número ``n`` se define como el producto de todos los
    enteros positivos desde 1 hasta ``n``. Por convención, el factorial de 0 es 1.

    :param lista: lista de números enteros no negativos.
    :type : lista
    :return: lista del factorial de n números dados.
    :rtype: lista de enteros
    :raises ValueError: Si alguno de los números proporcionados es negativo.

    Examples
    --------
    >>> r = factorial([1100])
    >>> str(r[0])[0:26] == '53437084880926377034242155'
    True
    >>> factorial([0])
    [1]
    >>> factorial([1])
    [1]
    >>> factorial([-4])
    Traceback (most recent call last):
      ...
    ValueError: El número debe ser un entero no negativo.
    """
    res = []
    for n in lista:
        if n > 1000:
            res.append( factorial_iterativo(n))
        else:
            res.append(factorial_rec(n))
    return res

