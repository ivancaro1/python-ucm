
"""
Recolección de datos
"""
import pandas as pd
import importlib.resources


def carga_csv(path: str) -> pd.DataFrame:
    return pd.read_csv(path)

def mayor(empleados: pd.DataFrame):
    r = empleados.edad.max()
    return int(r)

def read_data(filename: str|None = None) -> pd.DataFrame:
    """
    This function reads a file with the required format. It returns store dictionary
    >>> read_data().columns
    Index(['Codigo', 'Nombre', 'Precio'], dtype='str')
    >>> df = read_data()
    >>> list(df.columns)
    ['Codigo', 'Nombre', 'Precio']
    """
    if filename == None:
        # importlib.resources.files('funciones_pk') devuelve la raiz del paquete
        filename = importlib.resources.files('funciones_pk').joinpath('data/store2.txt')

    df = pd.read_csv(filename, sep = '|')

    return df

if __name__ == "__main__":
    print(read_data().Precio.isnull().sum())