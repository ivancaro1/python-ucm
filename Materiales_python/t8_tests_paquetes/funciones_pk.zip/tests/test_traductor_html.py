import pytest
import funciones_pk.traductor_html as traductor

"""
parchear traductor.requests.get
"""

# Tests para funciones que trabajan con ficheros
from pathlib import Path

#  FIXTURE_DIR define la carpeta donde se encuentra el archivo de prueba,
#  relativa al archivo actual. Esto permite localizar el fichero 
#  apartamento.html sin depender de la carpeta actual de ejecución.
FIXTURE_DIR = Path(__file__).parent.resolve() / 'data'

#  Fixture para leer el HTML . SE abre el fichero HTML y devuelve su
#  contenido como texto. Así el test no necesita leer el HTML manualmente.
#  Esto es útil porque queremos simular la respuesta real de Wikipedia.
@pytest.fixture
def apartamento():
    path = FIXTURE_DIR / "apartamento.html"
    with open(path, encoding="utf-8") as f:
        return f.read()

    
# Clase simulada de respuesta HTTP   
# simula la respuesta que devuelve requests.get()
class MockResponse:
    def __init__ (self , text ):
        self.status_code = 200
        self.text = text

# Fixture que devuelve una respuesta simulada        
@pytest.fixture
def mock_resp_apartamento(apartamento ):
    return MockResponse(apartamento)

# Datos a probar
traducciones = [
        ( 'apartamento' , 'de' , 'Wohnung' ),
        ( 'apartamento' , 'pt' ,  'Apartamento' ),
        ( 'apartamento' , 'en' , 'Apartment' ),
        ( 'apartamento' , 'fr' ,  'Appartement' ),
        ( 'apartamento' , 'XYZ' , None ),
        ('XYZ' , 'en' , None )
]
# Función de prueba
@pytest.mark.parametrize('palabra , idioma , esperado', traducciones)
def test_traduce_wikipedia_2 (monkeypatch ,
                              mock_resp_apartamento ,
                              palabra , idioma , esperado ):
    def mock_get(*args , **kwargs ):
        if palabra == 'apartamento' :
            return mock_resp_apartamento
        else :
            return MockResponse('')
            
    # Sustitución con monkeypatch        
    monkeypatch.setattr(traductor.requests , 'get' , mock_get )
    assert traductor.traduce_wikipedia( palabra , idioma ) == esperado

# monkeypatch es la herramienta de pytest para cambiar temporamente valores