import pytest

if __name__ == '__main__':
    # Ejecuta pytest en el directorio `tests/` para correr todos los archivos de prueba
    pytest.main(["../tests/"])