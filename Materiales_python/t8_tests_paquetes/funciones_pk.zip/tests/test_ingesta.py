from funciones_pk.ingesta_datos_api import mayor, read_data
import pytest
import pandas as pd

# Pytest con fixtures
###################################################################
# Pytest con fixtures

# Tests para funciones que trabajan con ficheros
from pathlib import Path

#  FIXTURE_DIR define la carpeta donde se encuentran los archivos de prueba, relativa al archivo actual
FIXTURE_DIR = Path(__file__).parent.resolve() / 'data'
# Posteriormente, pytest.mark.datafiles marca los archivos que queremos incluir como datos de prueba.
FILES = pytest.mark.datafiles(
    FIXTURE_DIR / 'store.txt',
    FIXTURE_DIR / 'store2.txt',
    FIXTURE_DIR / 'empleados.csv',
)
# La fixture files itera sobre los archivos proporcionados por datafiles, devolviendo un diccionario
# donde las claves son los nombres de archivo y los valores son las rutas completas.
@pytest.fixture
def files(datafiles):
    d = dict()
    for fname in datafiles.iterdir():
        d[fname.name] = fname.as_posix()
    return d

@pytest.fixture
def dataset_empleados(files):
    return pd.read_csv(files['empleados.csv'], sep = ',')


# Test 1: test read_data. Comprobar el parámetro por defecto (filename=None)
def test_read_data_default():
    # Test con los datos en funciones_pk/data
    df = read_data()
    assert list(df.columns) == ['Codigo', 'Nombre', 'Precio']
    assert df.Precio.isnull().sum() == 0

# Test 2: test read_data. Comprobar pasando un archivo explícito mediante la fixture 'files'
@FILES
def test_read_data_with_custom_file(files):
    # 'files' es el diccionario que mapea 'store2.txt' a su ruta temporal
    path_store2 = files['store2.txt']
    df = read_data(path_store2)
    assert isinstance(df, pd.DataFrame)
    assert len(df) > 0
    assert 'Codigo' in df.columns


# Test 3: test carga_mayor
@FILES
def test_mayor(dataset_empleados):
        assert type(dataset_empleados) == pd.DataFrame
        assert mayor(dataset_empleados) == 35

