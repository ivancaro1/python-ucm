from funciones_pk import gcd
import doctest
import pytest


# test  definidos en el docstring
###################################
def test_gcd_1():
    # Podemos ejecutar los tests en el docstring
    doctest.run_docstring_examples(gcd, globals())


# Tests en el marco pytest
###############################
def test_gcd_2():
    # test sin parámetros
    assert gcd(4, 6) == 2
    assert gcd(4, 7) == 1
    assert gcd(6, 7) == 1
    assert gcd(15, 5) == 5


# Tests en el marco pytest con decorador
#########################################
# Usamos el decorador parametrize para probar múltiples casos
@pytest.mark.parametrize("a, b, resultado_esperado", [
    (4, 6, 2),
    (4, 7, 1),
    (6, 7, 1),
    (15, 5, 5)
])
def test_gcd_22(a, b, resultado_esperado):
    # test con parámetros
    assert gcd(a, b) == resultado_esperado


@pytest.mark.parametrize(
    "a,b,expected",[
        (2**3 * 3 * 5**2, 2**3 * 7 * 5**1, 2**3 * 5),
        (2**3 * 3 * 5**2 * 7, 2**3 * 7 * 5**1, 2**3 * 5 * 7)
        ]
)
def test_gcd_3(a, b, expected):
    # Se toma a,b y expected de los parámetros de arriba
    assert gcd(a, b) == expected


@pytest.mark.parametrize(
    "a,b",[(0, 0), (-1, 2), (2, 0), (2, -11)])
def test_gcd2(a,b):
    with pytest.raises(ValueError):
        gcd(a,b)


if __name__ == "__main__":
    # Ejecuta pytest y pasa el archivo actual como argumento
    pytest.main([__file__])