# test_tomorrow.py
import pytest
from datetime import date
import funciones_pk.tomorrow as tm

@pytest.mark.parametrize(
    "today, expected",
    [
        (date(2021, 1, 1), date(2021, 1, 2)),      # Cambio de día normal
        (date(2021, 12, 31), date(2022, 1, 1)),    # Cambio de año
        (date(2020, 2, 28), date(2020, 2, 29)),    # Año bisiesto (febrero tiene 29 días)
        (date(2020, 2, 29), date(2020, 3, 1)),     # Fin de febrero en año bisiesto
        (date(2021, 2, 28), date(2021, 3, 1)),     # Fin de febrero en año NO bisiesto
    ],
)
def test_tomorrow(monkeypatch, today, expected):
    # Creamos una clase 'MockDate' que hereda de 'date' y sobreescribe 'today()'
    class MockDate(date):
        @staticmethod
        def today():
            return today

    # Sustituimos la referencia de 'date' dentro del módulo 'tomorrow' por nuestra 'MockDate'
    monkeypatch.setattr(tm,"date", MockDate)

    # Verificación
    assert tm.calcular_tomorrow() == expected