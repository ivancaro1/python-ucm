from funciones_pk import factorial
import doctest
import pytest


def test_factorial():
    # Podemos ejecutar los tests en el docstring
    doctest.run_docstring_examples(factorial, globals())

@pytest.mark.parametrize(
    "n",[([-1]), ([-10]), ([-6])])
def test_factorial_2(n):
    with pytest.raises(ValueError):
        factorial(n)


@pytest.mark.parametrize(
    "n,expected",[ ([1], [1]), ([0], [1]), ([2], [2]), ([3], [6])  ]
)
def test_factorial_3(n ,expected):
    # Se toma a,b y expected de los parámetros de arriba
    assert factorial(n) == expected

# Pytest con fixtures
# Definimos un fixture llamado 'datos_input'
@pytest.fixture
def datos_input():
    return [1, 2, 3, 4, 5]

@pytest.fixture
def datos_output():
    return [1, 2, 6, 24, 120]

# Usamos el fixture en una prueba
def test_factorial_4(datos_input, datos_output):
    assert factorial(datos_input) == datos_output

if __name__ == "__main__":
    # Ejecuta pytest y pasa el archivo actual como argumento
    pytest.main([__file__])